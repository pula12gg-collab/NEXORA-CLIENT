package com.nexora.client.config;

import com.nexora.client.NexoraClient;
import com.nexora.client.modules.ClientModule;
import com.nexora.client.modules.ModuleManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class ConfigStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("nexora-client.json");
    public void load(ModuleManager manager) {
        if (!Files.isRegularFile(file)) return;
        try (Reader reader=Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            Type type=new TypeToken<Map<String,Boolean>>(){}.getType();
            Map<String,Boolean> values=GSON.fromJson(reader,type);
            if(values!=null) values.forEach((name,enabled)->manager.find(name).ifPresent(m->m.setEnabled(Boolean.TRUE.equals(enabled))));
        } catch (Exception e) { System.err.println("[NEXORA] Could not read config: "+e.getMessage()); }
    }
    public void save(ModuleManager manager) {
        try {
            Files.createDirectories(file.getParent());
            Map<String,Boolean> values=new LinkedHashMap<>();
            for(ClientModule m:manager.all()) values.put(m.name(),m.enabled());
            try(Writer writer=Files.newBufferedWriter(file,StandardCharsets.UTF_8)) { GSON.toJson(values,writer); }
        } catch(Exception e) { System.err.println("[NEXORA] Could not save config: "+e.getMessage()); }
    }
}

package com.nexora.client;

import com.nexora.client.config.ConfigStore;
import com.nexora.client.gui.ClickGuiScreen;
import com.nexora.client.keybinds.NexoraKeybindings;
import com.nexora.client.modules.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public final class NexoraClient implements ClientModInitializer {
    public static final String MOD_ID = "nexora";
    public static final ModuleManager MODULES = new ModuleManager();
    public static final ConfigStore CONFIG = new ConfigStore();

    @Override
    public void onInitializeClient() {
        CONFIG.load(MODULES);
        NexoraKeybindings.register();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (NexoraKeybindings.OPEN_GUI.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
                else if (client.currentScreen instanceof ClickGuiScreen) client.setScreen(null);
            }
            MODULES.tick(client);
        });
        Runtime.getRuntime().addShutdownHook(new Thread(() -> CONFIG.save(MODULES)));
    }

    public static MinecraftClient client() { return MinecraftClient.getInstance(); }
}

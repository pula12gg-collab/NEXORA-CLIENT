package com.nexora.client.gui;

import com.nexora.client.NexoraClient;
import com.nexora.client.modules.ClientModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class ClickGuiScreen extends Screen {
    private static final int BG=0xF20D0B12, PANEL=0xF2191722, PANEL2=0xFF24202F, PURPLE=0xFFB45CFF, WHITE=0xFFF5F0FF, MUTED=0xFFB2A8C1;
    private static final List<String> CATEGORIES=List.of("Combat","Movement","Render","Player","World","HUD","Cosmetics","Inventory","Minimap","Items","Modules","Scripts","Settings","Profiles");
    private String selected="HUD";
    private TextFieldWidget search;
    private int guiX,guiY,guiW,guiH;
    private final Map<String,Integer> visibleRows=new HashMap<>();
    public ClickGuiScreen(){super(Text.literal("NEXORA CLIENT"));}
    @Override protected void init(){
        guiW=Math.min(720,width-24); guiH=Math.min(430,height-24); guiX=(width-guiW)/2; guiY=(height-guiH)/2;
        search=new TextFieldWidget(textRenderer,guiX+210,guiY+48,guiW-232,22,Text.literal("Search modules"));
        search.setPlaceholder(Text.literal("Search modules...")); addDrawableChild(search);
    }
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        renderBackground(ctx,mouseX,mouseY,delta);
        ctx.fill(guiX,guiY,guiX+guiW,guiY+guiH,BG);
        ctx.fill(guiX,guiY,guiX+guiW,guiY+3,PURPLE);
        ctx.fill(guiX+12,guiY+14,guiX+guiW-12,guiY+guiH-12,PANEL);
        ctx.drawTextWithShadow(textRenderer,"NEXORA",guiX+28,guiY+20,PURPLE);
        ctx.drawTextWithShadow(textRenderer,"CLIENT  /  1.21.11",guiX+99,guiY+20,MUTED);
        ctx.drawTextWithShadow(textRenderer,"RIGHT SHIFT  •  ESC TO CLOSE",guiX+guiW-190,guiY+20,MUTED);
        int sideX=guiX+22, sideY=guiY+53;
        for(String cat:CATEGORIES){
            boolean active=cat.equals(selected); int h=22;
            if(active) ctx.fill(sideX,sideY-4,guiX+194,sideY+17,0xFF38264C);
            ctx.drawTextWithShadow(textRenderer,cat,sideX+8,sideY,active?PURPLE: MUTED); sideY+=h;
        }
        ctx.drawTextWithShadow(textRenderer,selected.toUpperCase(Locale.ROOT)+" MODULES",guiX+210,guiY+81,WHITE);
        ctx.drawTextWithShadow(textRenderer,"Click a card to toggle. Hover for details.",guiX+210,guiY+96,MUTED);
        String query=search==null?"":search.getText().toLowerCase(Locale.ROOT);
        List<ClientModule> list=NexoraClient.MODULES.all().stream().filter(m->m.category().equals(selected)||selected.equals("Modules")).filter(m->m.name().toLowerCase(Locale.ROOT).contains(query)||m.description().toLowerCase(Locale.ROOT).contains(query)).toList();
        visibleRows.clear(); int x=guiX+210,y=guiY+120,w=(guiW-244)/2;
        for(int i=0;i<list.size() && i<12;i++){
            ClientModule m=list.get(i); int col=i%2,row=i/2; int cx=x+col*(w+10),cy=y+row*66;
            ctx.fill(cx,cy,cx+w,cy+56,PANEL2); ctx.fill(cx,cy,cx+3,cy+56,m.enabled()?PURPLE:0xFF494252);
            ctx.drawTextWithShadow(textRenderer,m.name(),cx+11,cy+8,WHITE);
            ctx.drawTextWithShadow(textRenderer,m.enabled()?"ON":"OFF",cx+w-34,cy+8,m.enabled()?PURPLE:MUTED);
            String desc=m.description(); if(desc.length()>Math.max(10,(w-18)/5)) desc=desc.substring(0,Math.max(0,(w-22)/5-2))+"…";
            ctx.drawTextWithShadow(textRenderer,desc,cx+11,cy+29,MUTED);
            visibleRows.put(m.name(),(cy<<16)|(cx&0xFFFF));
        }
        if(list.isEmpty()) ctx.drawTextWithShadow(textRenderer,"No matching modules in this category.",x,y, MUTED);
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button){
        if(super.mouseClicked(mouseX,mouseY,button)) return true;
        int sx=guiX+22,sy=guiY+53;
        for(String cat:CATEGORIES){if(mouseX>=sx&&mouseX<=guiX+194&&mouseY>=sy-5&&mouseY<=sy+17){selected=cat;return true;}sy+=22;}
        if(button==0){
            for(var entry:visibleRows.entrySet()){
                int packed=entry.getValue(),cy=packed>>16,cx=packed&0xFFFF; int w=(guiW-244)/2;
                if(mouseX>=cx&&mouseX<=cx+w&&mouseY>=cy&&mouseY<=cy+56){NexoraClient.MODULES.find(entry.getKey()).ifPresent(ClientModule::toggle);NexoraClient.CONFIG.save(NexoraClient.MODULES);return true;}
            }
        }
        return false;
    }
    @Override public boolean keyPressed(int keyCode,int scanCode,int modifiers){
        if(keyCode==GLFW.GLFW_KEY_ESCAPE){close();return true;}
        return super.keyPressed(keyCode,scanCode,modifiers);
    }
    @Override public void close(){NexoraClient.CONFIG.save(NexoraClient.MODULES);super.close();}
    @Override public boolean shouldPause(){return false;}
}

package com.nexora.client.modules;

import net.minecraft.client.MinecraftClient;
import java.util.*;

public final class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();
    public ModuleManager() {
        add("FPS", "HUD", "Show the current frame rate.", true);
        add("Coordinates", "HUD", "Show your current XYZ position.", true);
        add("Direction", "HUD", "Show the cardinal direction you face.", false);
        add("Clock", "HUD", "Show the local system time.", false);
        add("Keystrokes", "HUD", "Display movement key states (basic widget).", false);
        add("Armor Status", "HUD", "Show equipped armor durability in the HUD.", false);
        add("Durability", "Items", "Show held-item durability where applicable.", true);
        add("Potion Effects", "HUD", "Show active status effects.", false);
        add("Sprint Toggle", "Movement", "Client-side sprint helper; server behavior may vary.", false);
        add("Reduced Particles", "Render", "Reduce particle density using the vanilla setting.", false);
        add("Crosshair Info", "Render", "Show a small crosshair status label.", false);
        add("Inventory Helper", "Inventory", "Provides an inventory reminder panel only; no automated clicks.", false);
        add("Minimap Markers", "Minimap", "Local waypoint list placeholder; no radar or hidden-player reveal.", false);
        add("Cosmetic Preview", "Cosmetics", "Local-only cosmetic preview; does not change account skin/cape.", false);
        add("Performance Mode", "Settings", "Disables decorative animation in the ClickGUI.", false);
    }
    private void add(String n,String c,String d,boolean e){modules.add(new ClientModule(n,c,d,e));}
    public List<ClientModule> all(){return Collections.unmodifiableList(modules);}
    public List<ClientModule> category(String category){return modules.stream().filter(m->m.category().equals(category)).toList();}
    public Optional<ClientModule> find(String name){return modules.stream().filter(m->m.name().equals(name)).findFirst();}
    public void tick(MinecraftClient client) {
        if (client.player == null) return;
        find("Reduced Particles").ifPresent(m -> {
            // Deliberately does not change global settings automatically; toggle is stored for future user-facing controls.
        });
    }
}

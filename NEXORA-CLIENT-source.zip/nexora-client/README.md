# NEXORA CLIENT — Fabric 1.21.11

A client-side utility mod starter with a custom black/violet ClickGUI, Right Shift keybind, category navigation, module search, module toggles, and persistent enabled-state configuration.

## Current implementation status

Implemented: Fabric client entrypoint, RIGHT SHIFT binding, ESC close, responsive custom ClickGUI, category navigation, module search, module toggle cards, JSON config load/save, Java 21 toolchain, and GitHub Actions build workflow.

Listed modules are a registry and user-facing UI. Many are intentionally not active gameplay features yet: this version does **not** claim to implement a complete HUD editor, minimap rendering, cosmetics/skin changes, visual effects, draggable widgets, profiles import/export, color pickers, sliders, or working inventory automation. These should be implemented and tested in later iterations rather than presented as finished features. No combat automation, hidden-player radar, server-protection bypass, credential collection, or hidden downloads are included.

## Build

Requirements: JDK 21 and network access to Maven Central, Fabric Maven, and the Gradle distribution service.

```bash
./gradlew build
```

The remapped mod JAR should be in `build/libs/` after a successful build. This source bundle includes wrapper scripts and wrapper configuration; if `gradle-wrapper.jar` is absent, regenerate the wrapper using an installed Gradle 8.14+ with `gradle wrapper --gradle-version 8.14.3` before using `./gradlew`.

## Install in Fabric / MjLauncher

1. Create or select a Minecraft Java **1.21.11** Fabric profile with Java 21.
2. Launch it once, then close Minecraft.
3. Put the built `nexora-client-*.jar` in that profile's `mods` folder.
4. Install the matching Fabric API for Minecraft 1.21.11 in the same `mods` folder.
5. Launch the Fabric profile and press **Right Shift** in-game.

MjLauncher folder locations vary by device and launcher settings. Use the game directory shown by MjLauncher; do not put the mod JAR inside the resourcepacks folder.

## Configuration

Module enabled states are stored in `.minecraft/config/nexora-client.json` (or the equivalent game directory configured by the launcher). Closing the GUI also saves settings.

## Safety

This is a client-side UI/utility project. A module label does not mean the corresponding feature is fully implemented. Follow each multiplayer server's rules; client-side visual or movement features may be restricted by some servers.
